-- =====================================================================
-- CRICKETHUB - ADVANCED SQL QUERIES & ANALYTICAL REPORTS
-- File: 05_advanced_queries.sql
-- Description:
--   Demonstrates ordinary SQL (non-PL/SQL) queries covering:
--   - Multi-table JOINs (3 to 5 tables)
--   - Aggregate functions (COUNT, SUM, AVG, MIN, MAX)
--   - GROUP BY and HAVING clauses
--   - Subqueries (correlated, IN, NOT IN, EXISTS)
--   - Analytical business reports for cricket academy management
-- =====================================================================

-- ---------------------------------------------------------------------
-- QUERY 1: MULTI-TABLE ATTENDANCE ROSTER (5-TABLE JOIN)
-- Purpose:
--   Retrieves full session attendance details linking Player, User,
--   Session, Trainer, and Venue.
-- Expected Result:
--   List of player names, session dates, trainer names, venue names,
--   and attendance status.
-- ---------------------------------------------------------------------
SELECT
    u_c.Name            AS Player_Name,
    c."Batting-Style"   AS Batting_Style,
    s.Session_date      AS Session_Date,
    s.Session_time      AS Session_Time,
    u_t.Name            AS Trainer_Name,
    v.Venu_name         AS Venue_Name,
    p.Attendance        AS Attendance_Status,
    p.Participation_time AS Duration_Logged
FROM PARTICIPATE_IN p
JOIN CRICKETER c        ON p.Cricketer_id = c.Cricketer_id
JOIN "USER" u_c         ON c.User_id = u_c.User_id
JOIN TRAINING_SESSION s ON p.Session_id = s.Session_id
JOIN TRAINER t          ON s.Trainer_id = t.Trainer_id
JOIN "USER" u_t         ON t.User_id = u_t.User_id
JOIN VENUE v            ON s.Venu_id = v.Venu_id
ORDER BY s.Session_date DESC, u_c.Name ASC;

-- ---------------------------------------------------------------------
-- QUERY 2: PROGRAM POPULARITY & ENROLLMENT METRICS (GROUP BY + AGGREGATES)
-- Purpose:
--   Calculates total applications, approved count, pending count,
--   and approval percentage for each cricket training program.
-- Expected Result:
--   One row per program with total applications and computed breakdown.
-- ---------------------------------------------------------------------
SELECT
    cp.Program_id,
    cp.Program_name,
    cp.Duration,
    COUNT(a.Cricketer_id) AS Total_Applicants,
    SUM(CASE WHEN a.Applied_status = 'Approved' THEN 1 ELSE 0 END) AS Approved_Count,
    SUM(CASE WHEN a.Applied_status = 'Pending' THEN 1 ELSE 0 END) AS Pending_Count,
    ROUND(
        NVL(
            (SUM(CASE WHEN a.Applied_status = 'Approved' THEN 1 ELSE 0 END) * 100.0) /
            NULLIF(COUNT(a.Cricketer_id), 0),
            0
        ), 2
    ) AS Approval_Rate_Pct
FROM CRICKET_PROGRAM cp
LEFT JOIN APPLIED_TO a ON cp.Program_id = a.Program_id
GROUP BY cp.Program_id, cp.Program_name, cp.Duration
ORDER BY Total_Applicants DESC;

-- ---------------------------------------------------------------------
-- QUERY 3: FINANCIAL REVENUE & OUTSTANDING DUES AUDIT (GROUP BY + HAVING)
-- Purpose:
--   Summarizes total fees, paid amounts, and outstanding dues per program.
--   Filters programs having pending dues greater than 0 using HAVING.
-- Expected Result:
--   Programs with active outstanding amounts needing follow-up.
-- ---------------------------------------------------------------------
SELECT
    cp.Program_name,
    COUNT(pay.Cricketer_id) AS Total_Billing_Records,
    SUM(pay.Amount) AS Total_Expected_Revenue,
    SUM(CASE WHEN pay.Payment_Status = 'Paid' THEN pay.Amount ELSE 0 END) AS Total_Collected,
    SUM(CASE WHEN pay.Payment_Status = 'Pending' THEN pay.Amount ELSE 0 END) AS Total_Outstanding
FROM CRICKET_PROGRAM cp
JOIN PAYMENT pay ON cp.Program_id = pay.Program_id
GROUP BY cp.Program_name
HAVING SUM(CASE WHEN pay.Payment_Status = 'Pending' THEN pay.Amount ELSE 0 END) > 0
ORDER BY Total_Outstanding DESC;

-- ---------------------------------------------------------------------
-- QUERY 4: ACTIVE TRAINER WORKLOAD & CAPACITY UTILIZATION
-- Purpose:
--   Aggregates sessions conducted and total distinct players trained
--   by each certified coach.
-- Expected Result:
--   Trainer names, specialization, total sessions hosted, and players coached.
-- ---------------------------------------------------------------------
SELECT
    u.Name AS Trainer_Name,
    t.Specialization,
    t.Qualification,
    COUNT(DISTINCT s.Session_id) AS Sessions_Scheduled,
    COUNT(pi.Cricketer_id) AS Total_Player_Attendances,
    COUNT(DISTINCT pi.Cricketer_id) AS Unique_Cricketers_Trained
FROM TRAINER t
JOIN "USER" u ON t.User_id = u.User_id
LEFT JOIN TRAINING_SESSION s ON t.Trainer_id = s.Trainer_id
LEFT JOIN PARTICIPATE_IN pi ON s.Session_id = pi.Session_id AND pi.Attendance = 'Present'
GROUP BY u.Name, t.Specialization, t.Qualification
ORDER BY Sessions_Scheduled DESC;

-- ---------------------------------------------------------------------
-- QUERY 5: SUBQUERY (IN) - PLAYERS ENROLLED IN HIGH-INTENSITY PROGRAMS
-- Purpose:
--   Finds all cricketers who applied for programs lasting 3 months or longer.
-- Expected Result:
--   Player IDs, player names, and phone numbers.
-- ---------------------------------------------------------------------
SELECT
    c.Cricketer_id,
    u.Name AS Cricketer_Name,
    u.Phone,
    u.Address
FROM CRICKETER c
JOIN "USER" u ON c.User_id = u.User_id
WHERE c.Cricketer_id IN (
    SELECT a.Cricketer_id
    FROM APPLIED_TO a
    JOIN CRICKET_PROGRAM p ON a.Program_id = p.Program_id
    WHERE LOWER(p.Duration) LIKE '%3 month%' OR LOWER(p.Duration) LIKE '%6 month%'
);

-- ---------------------------------------------------------------------
-- QUERY 6: SUBQUERY (NOT EXISTS) - CRICKETERS WITH ZERO OVERDUE PAYMENTS
-- Purpose:
--   Identifies disciplined cricketers who have no pending or failed fees.
-- Expected Result:
--   Cricketers in good financial standing.
-- ---------------------------------------------------------------------
SELECT
    c.Cricketer_id,
    u.Name AS Cricketer_Name,
    u.Phone
FROM CRICKETER c
JOIN "USER" u ON c.User_id = u.User_id
WHERE NOT EXISTS (
    SELECT 1
    FROM PAYMENT p
    WHERE p.Cricketer_id = c.Cricketer_id
      AND p.Payment_Status IN ('Pending', 'Failed')
)
ORDER BY u.Name;

-- ---------------------------------------------------------------------
-- QUERY 7: INVENTORY UTILIZATION & CRITICAL STOCK ALERT
-- Purpose:
--   Reports on equipment assets, how many units are currently issued out,
--   available in store, and flags items where availability is critical (< 3).
-- Expected Result:
--   Equipment inventory breakdown with dynamic status flag.
-- ---------------------------------------------------------------------
SELECT
    eq.Equipment_id,
    eq.Equipment_name,
    eq.Equipment_type,
    eq.Total_Quantity,
    eq.Quantity AS Stock_In_Hand,
    NVL(SUM(CASE WHEN ei.Issue_status = 'Issued' THEN ei.Quantity ELSE 0 END), 0) AS Currently_Issued,
    CASE
        WHEN eq.Quantity = 0 THEN 'OUT OF STOCK'
        WHEN eq.Quantity <= 3 THEN 'CRITICAL / LOW STOCK'
        ELSE 'ADEQUATE'
    END AS Stock_Health
FROM EQUIPMENT eq
LEFT JOIN EQUIPMENT_ISSUED ei ON eq.Equipment_id = ei.Equipment_id
GROUP BY eq.Equipment_id, eq.Equipment_name, eq.Equipment_type, eq.Total_Quantity, eq.Quantity
ORDER BY eq.Quantity ASC;

-- ---------------------------------------------------------------------
-- QUERY 8: VENUE OCCUPANCY REPORT (AGGREGATE + GROUP BY)
-- Purpose:
--   Counts total sessions hosted across venues to evaluate utilization.
-- Expected Result:
--   Venues with capacity, availability, and session count.
-- ---------------------------------------------------------------------
SELECT
    v.Venu_id,
    v.Venu_name,
    v.Location,
    v.Capacity,
    v.Availability,
    COUNT(s.Session_id) AS Total_Sessions_Hosted
FROM VENUE v
LEFT JOIN TRAINING_SESSION s ON v.Venu_id = s.Venu_id
GROUP BY v.Venu_id, v.Venu_name, v.Location, v.Capacity, v.Availability
ORDER BY Total_Sessions_Hosted DESC;
