================================================================================
CRICKETHUB - CRICKET TRAINING & ACADEMY MANAGEMENT SYSTEM
Comprehensive Windows Setup, Database Deployment & Operational Guide
================================================================================

1. PROJECT PURPOSE & TECHNOLOGY STACK
--------------------------------------------------------------------------------
Crickethub is an enterprise-grade Cricket Training Management System built to
centralize and automate operations for cricket coaching academies. It manages
players, certified coaches, training curriculums, pitch allocations, session
schedules, academy gear inventory, player fees, and training attendance.

Technology Stack:
- Backend: Python 3.10+ with Flask 3.x
- Database: Oracle Database 19c / 21c XE (Express Edition) / Enterprise
- Oracle Driver: python-oracledb 2.x (Thin Mode - pure Python, no client binaries needed)
- Database Logic: SQL DDL/DML, Constraints, Views, PL/SQL Function, Stored Procedure,
  Explicit Cursor, and Database Trigger
- Frontend: HTML5, Accessible CSS3 (responsive custom cricket design system), Vanilla JS


2. COMPLETE FOLDER & FILE STRUCTURE
--------------------------------------------------------------------------------
CricketHub/
└── main/
    ├── app.py                     -> Flask web server, HTTP routes, session auth
    ├── db.py                      -> Oracle connection pool, RowDict mapping & helpers
    ├── repositories.py            -> Parameterized SQL queries for all 11 tables
    ├── requirements.txt           -> Python dependencies (Flask, oracledb, etc.)
    ├── README.txt                 -> This comprehensive setup guide
    ├── .env.example               -> Environment variable template
    ├── .gitignore                 -> Excludes venv, .env, and caches from git
    ├── database/
    │   ├── 01_authentication_user_management.sql  -> "USER", CRICKETER, TRAINER
    │   ├── 02_training_management.sql             -> CRICKET_PROGRAM, VENUE, TRAINING_SESSION
    │   ├── 03_finance_equipment.sql               -> EQUIPMENT, PAYMENT
    │   ├── 04_attendance_participation.sql        -> APPLIED_TO, EQUIPMENT_ISSUED, PARTICIPATE_IN
    │   ├── 05_advanced_queries.sql                -> Aggregates, Multi-table JOINs, Reports
    │   ├── 06_function.sql                        -> calculate_attendance_pct PL/SQL Function
    │   ├── 07_procedure.sql                       -> issue_equipment PL/SQL Stored Procedure
    │   ├── 08_cursor.sql                          -> cur_pending_payments Explicit Cursor
    │   ├── 09_trigger.sql                         -> trg_equipment_issue_update Stock Trigger
    │   └── 10_sample_data.sql                     -> Rerun-safe realistic cricket seed data
    ├── templates/
    │   ├── base.html              -> Master layout with navbar, subbar & flash messages
    │   ├── login.html             -> Secure sign-in page with demo accounts box
    │   ├── dashboard.html         -> Real-time Oracle metrics & quick action roster
    │   ├── users.html             -> User account management ("USER")
    │   ├── cricketers.html        -> Player profiles & styles (CRICKETER)
    │   ├── trainers.html          -> Coaches, credentials & salaries (TRAINER)
    │   ├── programs.html          -> Training curriculums (CRICKET_PROGRAM)
    │   ├── venues.html            -> Stadiums & nets (VENUE)
    │   ├── sessions.html          -> Training schedules (TRAINING_SESSION)
    │   ├── equipment.html         -> Inventory & stock tracking (EQUIPMENT)
    │   ├── payments.html          -> Player fee invoices & dues (PAYMENT)
    │   ├── applications.html      -> Program enrollments & review (APPLIED_TO)
    │   ├── equipment_issues.html  -> Checkout & return of gear (EQUIPMENT_ISSUED)
    │   └── participation.html     -> Player attendance & % rating (PARTICIPATE_IN)
    └── static/
        ├── css/style.css          -> Cricket turf green theme, typography & cards
        └── js/main.js             -> Modals, form population & confirmation dialogs


3. PREREQUISITES & WHY THEY ARE NEEDED
--------------------------------------------------------------------------------
1. Python 3.10+ (64-bit):
   Runs the Flask application web server and repository logic.
2. Oracle Database Server (e.g., Oracle Database 21c XE):
   Stores all relational data, executes constraints, and runs PL/SQL objects.
   *NOTE*: SQL*Plus is merely a command-line client. You MUST have the actual
   Oracle Database engine installed and running (OracleServiceXE service).
3. Web Browser (Google Chrome, Edge, Firefox):
   For accessing the web user interface at http://localhost:5000.


4. VERIFYING PYTHON ON WINDOWS
--------------------------------------------------------------------------------
Open PowerShell or Command Prompt and test:

    python --version
    py --version

If Python is not recognized:
- Download Python from https://www.python.org/downloads/
- During installation, check the box: "Add python.exe to PATH".


5. CREATING AND ACTIVATING A VIRTUAL ENVIRONMENT
--------------------------------------------------------------------------------
Navigate to the project's 'main' directory:

    cd D:\study\DBMS\project\PROJECT_MAIN\CricketHub\main

Create a virtual environment named 'venv':

    python -m venv venv

Activate the virtual environment:
- On PowerShell:
    .\venv\Scripts\Activate.ps1
  (If script execution is disabled, run: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass)
- On Command Prompt (cmd.exe):
    .\venv\Scripts\activate.bat


6. INSTALLING DEPENDENCIES
--------------------------------------------------------------------------------
With the virtual environment activated:

    pip install -r requirements.txt

Verify installed packages:

    pip list
    (You should see Flask, oracledb, python-dotenv, and Werkzeug)


7. UNDERSTANDING SQL*PLUS VS. ORACLE DATABASE SERVER
--------------------------------------------------------------------------------
- SQL*Plus is a command-line terminal client used to send SQL queries to an
  Oracle database engine.
- Having SQL*Plus does NOT mean you have an active database. You must ensure the
  Oracle Database Service (e.g. OracleServiceXE) and Oracle TNS Listener
  (OracleOraDB21Home1TNSListener) are running in Windows Services (services.msc).


8. CONNECTING TO ORACLE USING SQL*PLUS
--------------------------------------------------------------------------------
Open PowerShell or Command Prompt and connect as SYSDBA to administrative level:

    sqlplus sys as sysdba

When prompted, enter your Oracle SYS password.
Once connected, check your database container:

    SHOW CON_NAME;
    (In 21c XE, this will usually show CDB$ROOT or XEPDB1)


9. CREATING DEDICATED ORACLE PROJECT USER & PRIVILEGES
--------------------------------------------------------------------------------
Generating project files does NOT automatically create the database user.
In SQL*Plus as SYSDBA, create a dedicated project user/schema:

    ALTER SESSION SET "_ORACLE_SCRIPT"=true;

    -- Replace [YOUR_CHOSEN_PASSWORD] with your own secure password:
    CREATE USER crickethub_admin IDENTIFIED BY [YOUR_CHOSEN_PASSWORD];

    -- Grant essential permissions:
    GRANT CONNECT, RESOURCE, CREATE VIEW, CREATE PROCEDURE, CREATE TRIGGER TO crickethub_admin;
    GRANT UNLIMITED TABLESPACE TO crickethub_admin;

    EXIT;

Now test logging in as your newly created project user:

    sqlplus crickethub_admin/[YOUR_CHOSEN_PASSWORD]@localhost:1521/XE


10. CONFIGURING ENVIRONMENT VARIABLES (.env)
--------------------------------------------------------------------------------
Inside 'D:\study\DBMS\project\PROJECT_MAIN\CricketHub\main':

1. Make a copy of '.env.example' and rename it to '.env':
   In PowerShell:
       Copy-Item .env.example .env

2. Open '.env' in any text editor and fill in your actual connection details:
[ python -c "import secrets; print(secrets.token_hex(32))" ] this to get the secret key.

       FLASK_APP=app.py
       FLASK_ENV=development
       FLASK_DEBUG=1
       SECRET_KEY=enter_any_secure_random_text_string_here

       ORACLE_USER=crickethub_admin
       ORACLE_PASSWORD=[YOUR_CHOSEN_PASSWORD]
       ORACLE_HOST=localhost
       ORACLE_PORT=1521
       ORACLE_SERVICE=XE

*NEVER instruct anyone to leave default or example passwords unchanged.*


11. RUNNING SQL FILES IN THE CORRECT EXECUTION ORDER
--------------------------------------------------------------------------------
Because of foreign key dependencies, the SQL scripts MUST be executed in this
exact sequence:

Open PowerShell, navigate to 'main/database', and run SQL*Plus:

    cd D:\study\DBMS\project\PROJECT_MAIN\CricketHub\main\database
    sqlplus crickethub_admin/[YOUR_CHOSEN_PASSWORD]@localhost:1521/XE

Run the scripts in sequence:

    @01_authentication_user_management.sql
    @02_training_management.sql
    @03_finance_equipment.sql
    @04_attendance_participation.sql
    @06_function.sql
    @07_procedure.sql
    @08_cursor.sql
    @09_trigger.sql
    @10_sample_data.sql

Verify all 11 tables exist:

    SELECT table_name FROM user_tables ORDER BY table_name;

Expected Output (11 tables):
- APPLIED_TO
- CRICKET_PROGRAM
- CRICKETER
- EQUIPMENT
- EQUIPMENT_ISSUED
- PARTICIPATE_IN
- PAYMENT
- TRAINING_SESSION
- TRAINER
- USER (quoted as "USER")
- VENUE

You can also run '@05_advanced_queries.sql' to view multi-table join reports.


12. STARTING FLASK AND OPENING THE APPLICATION
--------------------------------------------------------------------------------
From 'D:\study\DBMS\project\PROJECT_MAIN\CricketHub\main' (with venv active):

    python app.py

Output will show:
    * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)

Open your web browser and navigate to:
    http://localhost:5000/

Log in using one of the pre-seeded accounts:
- Super Admin : User ID: 1 | Password: password123
- System User : User ID: 2 | Password: password123
- Trainer     : User ID: 3 | Password: password123
- Cricketer   : User ID: 6 | Password: password123


13. TESTING MODULES, FUNCTIONS, PROCEDURES, CURSORS, TRIGGERS
--------------------------------------------------------------------------------
- PL/SQL Function (calculate_attendance_pct):
  * Test in SQL*Plus:
    SELECT calculate_attendance_pct(1) AS attendance_pct FROM DUAL;
  * Test in Web App:
    Log in as Cricketer (ID 6). The top banner dynamically computes attendance %.

- PL/SQL Procedure (issue_equipment) & Trigger (trg_equipment_issue_update):
  * In the Web App, visit 'Gear Checkouts' -> click '+ Checkout / Issue Gear'.
  * Select Cricketer #1 and Equipment #1 (qty: 1).
  * The procedure validates stock, inserts into EQUIPMENT_ISSUED, and the
    database trigger automatically decreases available Quantity in EQUIPMENT.
  * Click 'Mark Returned' -> the trigger automatically restores available Quantity!

- PL/SQL Explicit Cursor (cur_pending_payments):
  * Run in SQL*Plus:
    @08_cursor.sql
  * Iteratively loops through pending invoices and prints summary totals via DBMS_OUTPUT.


14. TROUBLESHOOTING GUIDE
--------------------------------------------------------------------------------
1. ORA-12541: TNS:no listener / ORA-12514: TNS:listener does not currently know of service
   - Solution: Open Windows Services (Win + R -> services.msc).
   - Ensure 'OracleOraDB21Home1TNSListener' and 'OracleServiceXE' are in Running state.
   - Verify ORACLE_SERVICE=XE or XEPDB1 in your .env file.

2. ORA-01017: invalid username/password; logon denied
   - Solution: Double-check ORACLE_USER and ORACLE_PASSWORD in .env.
   - Reset password in SQL*Plus as sysdba: ALTER USER crickethub_admin IDENTIFIED BY newpass;

3. ORA-00942: table or view does not exist
   - Solution: Ensure you executed 01 through 04 SQL scripts in crickethub_admin schema.
   - Remember that table "USER" must be referenced with double quotes in raw SQL.

4. ModuleNotFoundError: No module named 'flask' / 'oracledb'
   - Solution: Ensure virtual environment is activated (.\venv\Scripts\Activate.ps1).
   - Run: pip install -r requirements.txt.


15. STOPPING FLASK
--------------------------------------------------------------------------------
To stop the Flask server in your terminal:
- Press CTRL + C.
- Deactivate virtual environment: deactivate


16. MANUAL VS. OPTIONAL STEPS
--------------------------------------------------------------------------------
- Manual (Required Once):
  * Creating Oracle database user and granting privileges (Step 9).
  * Configuring .env with your Oracle password (Step 10).
  * Executing schema scripts 01 through 10 in SQL*Plus (Step 11).
  * Installing pip requirements into virtual environment (Step 6).

- Optional:
  * Running 05_advanced_queries.sql and 08_cursor.sql directly in SQL*Plus
    (these are academic demonstration scripts for viva).


17. CONCISE RUN CHECKLIST FOR VIVA / DEMO
--------------------------------------------------------------------------------
[ ] 1. OracleServiceXE & TNS Listener are running in Windows Services.
[ ] 2. Schema tables and PL/SQL objects created via scripts 01 - 10.
[ ] 3. .env file configured with correct user/password/service.
[ ] 4. Virtual environment active: (venv) prompt visible.
[ ] 5. Run 'python app.py' inside 'main' directory.
[ ] 6. Open 'http://localhost:5000/' in browser.
[ ] 7. Log in with ID 1 / password123 to verify all modules end-to-end!
================================================================================
