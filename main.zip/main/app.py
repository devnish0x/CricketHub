"""
Crickethub - Flask Application Entrypoint
File: app.py
Description:
    Main Flask web application providing secure routes, authentication,
    form processing, and template rendering for the Cricket Training
    Management System.
"""

import os
from functools import wraps
from datetime import datetime
from dotenv import load_dotenv
from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, session, jsonify
)
from db import check_db_health
from repositories import (
    UserRepo, CricketerRepo, TrainerRepo, ProgramRepo,
    VenueRepo, SessionRepo, EquipmentRepo, PaymentRepo,
    ApplicationRepo, EquipmentIssueRepo, ParticipationRepo,
    DashboardRepo
)

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "crickethub_production_secret_key_2026")


# =====================================================================
# AUTHENTICATION DECORATORS & HELPERS
# =====================================================================
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        if session.get("role") not in ["Super Admin", "System User"]:
            flash("Administrative privilege required for this action.", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return decorated_function


@app.context_processor
def inject_global_vars():
    """Inject current year and user session into all Jinja templates."""
    return {
        "current_user": {
            "id": session.get("user_id"),
            "name": session.get("name"),
            "role": session.get("role")
        },
        "now": datetime.now()
    }


# =====================================================================
# AUTHENTICATION ROUTES
# =====================================================================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        password = request.form.get("password", "")

        if not identifier or not password:
            flash("Please provide both User ID / Phone and password.", "danger")
            return render_template("login.html")

        try:
            user = UserRepo.authenticate(identifier, password)
            if user:
                session["user_id"] = user["user_id"]
                session["name"] = user["name"]
                session["role"] = user["role"]

                # If cricketer or trainer, store profile ID in session
                if user["role"] == "Cricketer":
                    cricketer = CricketerRepo.get_by_user_id(user["user_id"])
                    if cricketer:
                        session["cricketer_id"] = cricketer["cricketer_id"]
                elif user["role"] == "Trainer":
                    # Look up trainer
                    trainers = TrainerRepo.list_all()
                    for t in trainers:
                        if t["user_id"] == user["user_id"]:
                            session["trainer_id"] = t["trainer_id"]
                            break

                flash(f"Welcome back, {user['name']}!", "success")
                next_page = request.args.get("next")
                return redirect(next_page or url_for("dashboard"))
            else:
                flash("Invalid credentials. Please verify your ID/Phone and password.", "danger")
        except Exception as e:
            flash(f"Database error during authentication: {str(e)}", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been signed out safely.", "info")
    return redirect(url_for("login"))


# =====================================================================
# DASHBOARD ROUTE
# =====================================================================
@app.route("/")
@app.route("/dashboard")
@login_required
def dashboard():
    metrics = DashboardRepo.get_metrics()
    health = check_db_health()
    return render_template("dashboard.html", metrics=metrics, health=health)


# =====================================================================
# 1. USER MANAGEMENT ROUTES ("USER")
# =====================================================================
@app.route("/users", methods=["GET", "POST"])
@admin_required
def users():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                name = request.form.get("name")
                password = request.form.get("password")
                role = request.form.get("role")
                phone = request.form.get("phone")
                address = request.form.get("address")
                UserRepo.create(name, password, role, phone, address)
                flash(f"User '{name}' created successfully.", "success")

            elif action == "update":
                uid = request.form.get("user_id")
                name = request.form.get("name")
                role = request.form.get("role")
                phone = request.form.get("phone")
                address = request.form.get("address")
                pwd = request.form.get("password") or None
                UserRepo.update(uid, name, role, phone, address, pwd)
                flash("User profile updated successfully.", "success")

            elif action == "delete":
                uid = request.form.get("user_id")
                if int(uid) == session.get("user_id"):
                    flash("You cannot delete your own logged-in account.", "warning")
                else:
                    UserRepo.delete(uid)
                    flash("User account deleted successfully.", "success")
        except Exception as e:
            flash(f"Error performing user action: {str(e)}", "danger")

        return redirect(url_for("users"))

    search = request.args.get("search")
    role_filter = request.args.get("role")
    try:
        user_list = UserRepo.list_all(role=role_filter, search=search)
    except Exception as e:
        flash(f"Database error: {str(e)}. Please verify your Oracle credentials in .env.", "danger")
        user_list = []
    return render_template("users.html", users=user_list, search=search, role_filter=role_filter)


# =====================================================================
# 2. CRICKETER MANAGEMENT ROUTES (CRICKETER)
# =====================================================================
@app.route("/cricketers", methods=["GET", "POST"])
@login_required
def cricketers():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                name = request.form.get("name")
                password = request.form.get("password") or "password123"
                phone = request.form.get("phone")
                address = request.form.get("address")
                dob = request.form.get("dob")
                gender = request.form.get("gender")
                batting_style = request.form.get("batting_style")
                bowling_style = request.form.get("bowling_style")
                exp = request.form.get("experience", 0)
                CricketerRepo.create(name, password, phone, address, dob, gender, batting_style, bowling_style, exp)
                flash(f"Cricketer '{name}' registered successfully.", "success")

            elif action == "update":
                cid = request.form.get("cricketer_id")
                name = request.form.get("name")
                phone = request.form.get("phone")
                address = request.form.get("address")
                dob = request.form.get("dob")
                gender = request.form.get("gender")
                batting_style = request.form.get("batting_style")
                bowling_style = request.form.get("bowling_style")
                exp = request.form.get("experience", 0)
                CricketerRepo.update(cid, name, phone, address, dob, gender, batting_style, bowling_style, exp)
                flash("Cricketer details updated successfully.", "success")

            elif action == "delete":
                cid = request.form.get("cricketer_id")
                CricketerRepo.delete(cid)
                flash("Cricketer record deleted.", "success")
        except Exception as e:
            flash(f"Error managing cricketer: {str(e)}", "danger")

        return redirect(url_for("cricketers"))

    search = request.args.get("search")
    try:
        cricketer_list = CricketerRepo.list_all(search=search)
    except Exception as e:
        flash(f"Database error: {str(e)}. Please verify Oracle connection.", "danger")
        cricketer_list = []
    return render_template("cricketers.html", cricketers=cricketer_list, search=search)


# =====================================================================
# 3. TRAINER MANAGEMENT ROUTES (TRAINER)
# =====================================================================
@app.route("/trainers", methods=["GET", "POST"])
@login_required
def trainers():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                name = request.form.get("name")
                password = request.form.get("password") or "password123"
                phone = request.form.get("phone")
                address = request.form.get("address")
                specialization = request.form.get("specialization")
                exp = request.form.get("experience", 0)
                qualification = request.form.get("qualification")
                salary = request.form.get("salary", 0)
                TrainerRepo.create(name, password, phone, address, specialization, exp, qualification, salary)
                flash(f"Trainer '{name}' enrolled successfully.", "success")

            elif action == "update":
                tid = request.form.get("trainer_id")
                name = request.form.get("name")
                phone = request.form.get("phone")
                address = request.form.get("address")
                specialization = request.form.get("specialization")
                exp = request.form.get("experience", 0)
                qualification = request.form.get("qualification")
                salary = request.form.get("salary", 0)
                TrainerRepo.update(tid, name, phone, address, specialization, exp, qualification, salary)
                flash("Trainer profile updated.", "success")

            elif action == "delete":
                tid = request.form.get("trainer_id")
                TrainerRepo.delete(tid)
                flash("Trainer record removed.", "success")
        except Exception as e:
            flash(f"Error updating trainer: {str(e)}", "danger")

        return redirect(url_for("trainers"))

    search = request.args.get("search")
    try:
        trainer_list = TrainerRepo.list_all(search=search)
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        trainer_list = []
    return render_template("trainers.html", trainers=trainer_list, search=search)


# =====================================================================
# 4. CRICKET PROGRAMS (CRICKET_PROGRAM)
# =====================================================================
@app.route("/programs", methods=["GET", "POST"])
@login_required
def programs():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                pname = request.form.get("program_name")
                dur = request.form.get("duration")
                ProgramRepo.create(pname, dur)
                flash(f"Program '{pname}' created.", "success")
            elif action == "update":
                pid = request.form.get("program_id")
                pname = request.form.get("program_name")
                dur = request.form.get("duration")
                ProgramRepo.update(pid, pname, dur)
                flash("Program updated.", "success")
            elif action == "delete":
                pid = request.form.get("program_id")
                ProgramRepo.delete(pid)
                flash("Program removed.", "success")
        except Exception as e:
            flash(f"Error managing program: {str(e)}", "danger")

        return redirect(url_for("programs"))

    search = request.args.get("search")
    try:
        program_list = ProgramRepo.list_all(search=search)
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        program_list = []
    return render_template("programs.html", programs=program_list, search=search)


# =====================================================================
# 5. VENUES (VENUE)
# =====================================================================
@app.route("/venues", methods=["GET", "POST"])
@login_required
def venues():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                vname = request.form.get("venu_name")
                loc = request.form.get("location")
                cap = request.form.get("capacity", 50)
                avail = request.form.get("availability", "Available")
                VenueRepo.create(vname, loc, cap, avail)
                flash(f"Venue '{vname}' registered.", "success")
            elif action == "update":
                vid = request.form.get("venu_id")
                vname = request.form.get("venu_name")
                loc = request.form.get("location")
                cap = request.form.get("capacity")
                avail = request.form.get("availability")
                VenueRepo.update(vid, vname, loc, cap, avail)
                flash("Venue updated.", "success")
            elif action == "delete":
                vid = request.form.get("venu_id")
                VenueRepo.delete(vid)
                flash("Venue removed.", "success")
        except Exception as e:
            flash(f"Error managing venue: {str(e)}", "danger")

        return redirect(url_for("venues"))

    search = request.args.get("search")
    try:
        venue_list = VenueRepo.list_all(search=search)
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        venue_list = []
    return render_template("venues.html", venues=venue_list, search=search)


# =====================================================================
# 6. TRAINING SESSIONS (TRAINING_SESSION)
# =====================================================================
@app.route("/sessions", methods=["GET", "POST"])
@login_required
def sessions():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                sdate = request.form.get("session_date")
                stime = request.form.get("session_time")
                status = request.form.get("status", "Scheduled")
                tid = request.form.get("trainer_id")
                vid = request.form.get("venu_id")
                SessionRepo.create(sdate, stime, status, tid, vid)
                flash("Training session scheduled successfully.", "success")
            elif action == "update":
                sid = request.form.get("session_id")
                sdate = request.form.get("session_date")
                stime = request.form.get("session_time")
                status = request.form.get("status")
                tid = request.form.get("trainer_id")
                vid = request.form.get("venu_id")
                SessionRepo.update(sid, sdate, stime, status, tid, vid)
                flash("Session details updated.", "success")
            elif action == "delete":
                sid = request.form.get("session_id")
                SessionRepo.delete(sid)
                flash("Session cancelled/deleted.", "success")
        except Exception as e:
            flash(f"Error managing session: {str(e)}", "danger")

        return redirect(url_for("sessions"))

    status_filter = request.args.get("status")
    search = request.args.get("search")
    try:
        session_list = SessionRepo.list_all(status=status_filter, search=search)
        trainer_list = TrainerRepo.list_all()
        venue_list = VenueRepo.list_all()
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        session_list, trainer_list, venue_list = [], [], []
    return render_template("sessions.html", sessions=session_list, trainers=trainer_list, venues=venue_list, status_filter=status_filter, search=search)


# =====================================================================
# 7. EQUIPMENT INVENTORY (EQUIPMENT)
# =====================================================================
@app.route("/equipment", methods=["GET", "POST"])
@login_required
def equipment():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                ename = request.form.get("equipment_name")
                etype = request.form.get("equipment_type")
                tot = request.form.get("total_quantity", 0)
                qty = request.form.get("quantity", tot)
                avail = request.form.get("availability", "Available")
                EquipmentRepo.create(ename, etype, tot, avail, qty)
                flash(f"Equipment '{ename}' cataloged.", "success")
            elif action == "update":
                eid = request.form.get("equipment_id")
                ename = request.form.get("equipment_name")
                etype = request.form.get("equipment_type")
                tot = request.form.get("total_quantity")
                qty = request.form.get("quantity")
                avail = request.form.get("availability")
                EquipmentRepo.update(eid, ename, etype, tot, avail, qty)
                flash("Equipment updated.", "success")
            elif action == "delete":
                eid = request.form.get("equipment_id")
                EquipmentRepo.delete(eid)
                flash("Equipment record removed.", "success")
        except Exception as e:
            flash(f"Error updating equipment: {str(e)}", "danger")

        return redirect(url_for("equipment"))

    search = request.args.get("search")
    avail_filter = request.args.get("availability")
    try:
        equip_list = EquipmentRepo.list_all(search=search, availability=avail_filter)
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        equip_list = []
    return render_template("equipment.html", equipment=equip_list, search=search, avail_filter=avail_filter)


# =====================================================================
# 8. PAYMENTS & FINANCES (PAYMENT)
# =====================================================================
@app.route("/payments", methods=["GET", "POST"])
@login_required
def payments():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "create":
                cid = request.form.get("cricketer_id")
                pid = request.form.get("program_id")
                amt = request.form.get("amount")
                ddate = request.form.get("due_date")
                status = request.form.get("payment_status", "Pending")
                pdate = request.form.get("payment_date") or None
                PaymentRepo.create(cid, pid, amt, ddate, status, pdate)
                flash("Payment invoice created.", "success")

            elif action == "mark_paid":
                cid = request.form.get("cricketer_id")
                pid = request.form.get("program_id")
                ddate = request.form.get("due_date")
                PaymentRepo.update_status(cid, pid, ddate, "Paid")
                flash("Payment marked as PAID successfully.", "success")

            elif action == "delete":
                cid = request.form.get("cricketer_id")
                pid = request.form.get("program_id")
                ddate = request.form.get("due_date")
                PaymentRepo.delete(cid, pid, ddate)
                flash("Payment record deleted.", "success")
        except Exception as e:
            flash(f"Error processing payment: {str(e)}", "danger")

        return redirect(url_for("payments"))

    status_filter = request.args.get("status")
    search = request.args.get("search")

    # If cricketer role, restrict to own payments
    cid_filter = None
    if session.get("role") == "Cricketer":
        cid_filter = session.get("cricketer_id")

    try:
        payment_list = PaymentRepo.list_all(status=status_filter, cricketer_id=cid_filter, search=search)
        cricketers_list = CricketerRepo.list_all()
        program_list = ProgramRepo.list_all()
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        payment_list, cricketers_list, program_list = [], [], []
    return render_template("payments.html", payments=payment_list, cricketers=cricketers_list, programs=program_list, status_filter=status_filter, search=search)


# =====================================================================
# 9. PROGRAM APPLICATIONS (APPLIED_TO)
# =====================================================================
@app.route("/applications", methods=["GET", "POST"])
@login_required
def applications():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "apply":
                cid = request.form.get("cricketer_id")
                pid = request.form.get("program_id")
                ApplicationRepo.create(cid, pid, "Pending")
                flash("Application submitted successfully.", "success")

            elif action == "update_status":
                cid = request.form.get("cricketer_id")
                pid = request.form.get("program_id")
                new_stat = request.form.get("applied_status")
                ApplicationRepo.update_status(cid, pid, new_stat)
                flash(f"Application marked as '{new_stat}'.", "success")

            elif action == "delete":
                cid = request.form.get("cricketer_id")
                pid = request.form.get("program_id")
                ApplicationRepo.delete(cid, pid)
                flash("Application removed.", "success")
        except Exception as e:
            flash(f"Error with application: {str(e)}", "danger")

        return redirect(url_for("applications"))

    status_filter = request.args.get("status")
    search = request.args.get("search")

    cid_filter = None
    if session.get("role") == "Cricketer":
        cid_filter = session.get("cricketer_id")

    try:
        app_list = ApplicationRepo.list_all(status=status_filter, cricketer_id=cid_filter, search=search)
        cricketers_list = CricketerRepo.list_all()
        program_list = ProgramRepo.list_all()
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        app_list, cricketers_list, program_list = [], [], []
    return render_template("applications.html", applications=app_list, cricketers=cricketers_list, programs=program_list, status_filter=status_filter, search=search)


# =====================================================================
# 10. EQUIPMENT ISSUES & RETURNS (EQUIPMENT_ISSUED)
# =====================================================================
@app.route("/equipment-issues", methods=["GET", "POST"])
@login_required
def equipment_issues():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "issue":
                cid = request.form.get("cricketer_id")
                eid = request.form.get("equipment_id")
                qty = request.form.get("quantity", 1)
                res = EquipmentIssueRepo.issue_gear(cid, eid, qty)
                flash(res["message"], "success" if res["status"] == "SUCCESS" else "danger")

            elif action == "return":
                cid = request.form.get("cricketer_id")
                eid = request.form.get("equipment_id")
                idate = request.form.get("issue_date")
                EquipmentIssueRepo.return_gear(cid, eid, idate)
                flash("Gear marked as RETURNED. Inventory stock restored.", "success")

            elif action == "delete":
                cid = request.form.get("cricketer_id")
                eid = request.form.get("equipment_id")
                idate = request.form.get("issue_date")
                EquipmentIssueRepo.delete(cid, eid, idate)
                flash("Issue log removed.", "success")
        except Exception as e:
            flash(f"Error processing equipment checkout: {str(e)}", "danger")

        return redirect(url_for("equipment_issues"))

    status_filter = request.args.get("status")
    search = request.args.get("search")

    cid_filter = None
    if session.get("role") == "Cricketer":
        cid_filter = session.get("cricketer_id")

    try:
        issue_list = EquipmentIssueRepo.list_all(status=status_filter, cricketer_id=cid_filter, search=search)
        cricketers_list = CricketerRepo.list_all()
        equip_list = EquipmentRepo.list_all(availability="Available")
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        issue_list, cricketers_list, equip_list = [], [], []
    return render_template("equipment_issues.html", issues=issue_list, cricketers=cricketers_list, equipment=equip_list, status_filter=status_filter, search=search)


# =====================================================================
# 11. PARTICIPATION & ATTENDANCE (PARTICIPATE_IN)
# =====================================================================
@app.route("/participation", methods=["GET", "POST"])
@login_required
def participation():
    if request.method == "POST":
        action = request.form.get("action")
        try:
            if action == "record":
                cid = request.form.get("cricketer_id")
                sid = request.form.get("session_id")
                ptime = request.form.get("participation_time", "2 Hours")
                att = request.form.get("attendance", "Present")
                ParticipationRepo.record(cid, sid, ptime, att)
                flash("Attendance recorded.", "success")

            elif action == "update":
                cid = request.form.get("cricketer_id")
                sid = request.form.get("session_id")
                ptime = request.form.get("participation_time")
                att = request.form.get("attendance")
                ParticipationRepo.update(cid, sid, ptime, att)
                flash("Attendance updated.", "success")

            elif action == "delete":
                cid = request.form.get("cricketer_id")
                sid = request.form.get("session_id")
                ParticipationRepo.delete(cid, sid)
                flash("Attendance entry removed.", "success")
        except Exception as e:
            flash(f"Error recording attendance: {str(e)}", "danger")

        return redirect(url_for("participation"))

    sid_filter = request.args.get("session_id")
    search = request.args.get("search")

    cid_filter = None
    attendance_pct = None
    if session.get("role") == "Cricketer":
        cid_filter = session.get("cricketer_id")
        if cid_filter:
            try:
                attendance_pct = ParticipationRepo.get_attendance_percentage(cid_filter)
            except Exception:
                attendance_pct = None

    try:
        part_list = ParticipationRepo.list_all(session_id=sid_filter, cricketer_id=cid_filter, search=search)
        cricketers_list = CricketerRepo.list_all()
        session_list = SessionRepo.list_all()
    except Exception as e:
        flash(f"Database error: {str(e)}", "danger")
        part_list, cricketers_list, session_list = [], [], []

    return render_template(
        "participation.html",
        participations=part_list,
        cricketers=cricketers_list,
        sessions=session_list,
        sid_filter=sid_filter,
        search=search,
        attendance_pct=attendance_pct
    )


# =====================================================================
# DIAGNOSTICS & SYSTEM HEALTH
# =====================================================================
@app.route("/system-health")
@login_required
def system_health():
    return jsonify(check_db_health())


# =====================================================================
# ERROR HANDLERS
# =====================================================================
@app.errorhandler(404)
def page_not_found(e):
    return render_template("base.html", error_title="404 - Page Not Found", error_msg="The requested page does not exist."), 404


@app.errorhandler(500)
def internal_server_error(e):
    return render_template("base.html", error_title="500 - Server Error", error_msg=f"An unexpected internal error occurred: {str(e)}"), 500


if __name__ == "__main__":
    # Run development server
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
